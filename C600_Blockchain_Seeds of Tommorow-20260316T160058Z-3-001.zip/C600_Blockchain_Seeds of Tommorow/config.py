import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'smart-farming-secret-key-2026'
    
    DATABASE_PATH = 'smart_farming.db'
    
    GEMINI_API_KEY = 'AIzaSyBIKMrIOYkFLiMdb641DHiDNGglfO71Sdo'
    GEMINI_MODEL = 'gemini-2.5-flash'
    
    GANACHE_URL = 'http://127.0.0.1:7545'
    GANACHE_PRIVATE_KEY = '0x4e4e5024c8c9eae5993ac3891bcfac61da98999ac746f3ce86ba103e47e25e33'
    GANACHE_ACCOUNT_ADDRESS = '0xf1B5155AF71b44ba1959617D26174bF58E9014D7'
    
    UPLOAD_FOLDER = 'uploads'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}