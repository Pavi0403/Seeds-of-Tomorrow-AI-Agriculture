// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract FarmingPlatform {

    struct Product {
        uint256 productId;
        address farmerAddress;
        string farmerName;
        string cropName;
        uint256 quantity;
        uint256 price;
        string harvestDate;
        string cultivationMethod;
        uint256 timestamp;
        bool exists;
    }

    struct Transaction {
        uint256 transactionIndex;
        address buyerAddress;
        address farmerAddress;
        uint256 productId;
        string cropName;
        uint256 quantity;
        uint256 totalAmount;
        string transactionId;
        string paymentMethod;
        uint256 timestamp;
        bool exists;
    }

    mapping(uint256 => Product) public products;
    mapping(uint256 => Transaction) public transactions;

    uint256 public productCount = 0;
    uint256 public transactionCount = 0;

    event ProductListed(
        uint256 indexed productId,
        address indexed farmerAddress,
        string cropName,
        uint256 timestamp
    );

    event ProductSold(
        uint256 indexed transactionIndex,
        address indexed buyerAddress,
        address indexed farmerAddress,
        string cropName,
        uint256 totalAmount,
        uint256 timestamp
    );

    function addProduct(
        uint256 productId,
        string memory farmerName,
        string memory cropName,
        uint256 quantity,
        uint256 price,
        string memory harvestDate,
        string memory cultivationMethod
    ) public {
        productCount++;
        products[productId] = Product({
            productId: productId,
            farmerAddress: msg.sender,
            farmerName: farmerName,
            cropName: cropName,
            quantity: quantity,
            price: price,
            harvestDate: harvestDate,
            cultivationMethod: cultivationMethod,
            timestamp: block.timestamp,
            exists: true
        });
        emit ProductListed(productId, msg.sender, cropName, block.timestamp);
    }

    function addTransaction(
        uint256 productId,
        string memory cropName,
        uint256 quantity,
        uint256 totalAmount,
        string memory transactionId,
        string memory paymentMethod,
        address farmerAddress
    ) public {
        transactionCount++;
        transactions[transactionCount] = Transaction({
            transactionIndex: transactionCount,
            buyerAddress: msg.sender,
            farmerAddress: farmerAddress,
            productId: productId,
            cropName: cropName,
            quantity: quantity,
            totalAmount: totalAmount,
            transactionId: transactionId,
            paymentMethod: paymentMethod,
            timestamp: block.timestamp,
            exists: true
        });
        emit ProductSold(transactionCount, msg.sender, farmerAddress, cropName, totalAmount, block.timestamp);
    }

    function getProduct(uint256 productId) public view returns (
        address farmerAddress,
        string memory farmerName,
        string memory cropName,
        uint256 quantity,
        uint256 price,
        string memory harvestDate,
        string memory cultivationMethod,
        uint256 timestamp
    ) {
        require(products[productId].exists, "Product does not exist");
        Product memory p = products[productId];
        return (p.farmerAddress, p.farmerName, p.cropName, p.quantity, p.price, p.harvestDate, p.cultivationMethod, p.timestamp);
    }

    function getTransaction(uint256 index) public view returns (
        address buyerAddress,
        address farmerAddress,
        string memory cropName,
        uint256 quantity,
        uint256 totalAmount,
        string memory transactionId,
        string memory paymentMethod,
        uint256 timestamp
    ) {
        require(transactions[index].exists, "Transaction does not exist");
        Transaction memory t = transactions[index];
        return (t.buyerAddress, t.farmerAddress, t.cropName, t.quantity, t.totalAmount, t.transactionId, t.paymentMethod, t.timestamp);
    }
}