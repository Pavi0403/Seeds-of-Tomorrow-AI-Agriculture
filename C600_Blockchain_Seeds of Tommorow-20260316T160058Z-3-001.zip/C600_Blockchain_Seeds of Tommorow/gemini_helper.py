import google.generativeai as genai
from config import Config

genai.configure(api_key=Config.GEMINI_API_KEY)

def get_gemini_response(prompt):
    try:
        model = genai.GenerativeModel(Config.GEMINI_MODEL)
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"Error: {str(e)}"

def explain_crop_recommendation(crop_name, input_params):
    prompt = f"""
    The AI model recommended {crop_name} for cultivation based on the following soil and climate conditions:
    - Nitrogen (N): {input_params['N']} kg/ha
    - Phosphorus (P): {input_params['P']} kg/ha
    - Potassium (K): {input_params['K']} kg/ha
    - Temperature: {input_params['temperature']}°C
    - Humidity: {input_params['humidity']}%
    - pH: {input_params['ph']}
    - Rainfall: {input_params['rainfall']} mm
    
    Provide a brief explanation (3-4 sentences) of why this crop is suitable for these conditions and any additional tips for successful cultivation.
    """
    return get_gemini_response(prompt)

def explain_fertilizer_recommendation(fertilizer_name, input_params):
    prompt = f"""
    The AI model recommended {fertilizer_name} fertilizer based on the following parameters:
    - Temperature: {input_params['temperature']}°C
    - Humidity: {input_params['humidity']}%
    - Soil Moisture: {input_params['moisture']}%
    - Soil Type: {input_params['soil_type']}
    - Crop Type: {input_params['crop_type']}
    - Nitrogen: {input_params['nitrogen']} kg/ha
    - Potassium: {input_params['potassium']} kg/ha
    - Phosphorus: {input_params['phosphorous']} kg/ha
    
    Provide a brief explanation (3-4 sentences) of why this fertilizer is recommended and how to apply it effectively.
    """
    return get_gemini_response(prompt)

def explain_irrigation_recommendation(status, input_params):
    prompt = f"""
    The AI model predicted irrigation status as {status} based on the following conditions:
    - Soil Moisture: {input_params['soil_moisture']}%
    - Temperature: {input_params['temperature']}°C
    - Soil Humidity: {input_params['soil_humidity']}%
    - Air Temperature: {input_params['air_temperature']}°C
    - Wind Speed: {input_params['wind_speed']} km/h
    - Air Humidity: {input_params['air_humidity']}%
    - Wind Gust: {input_params['wind_gust']} km/h
    - Pressure: {input_params['pressure']} kPa
    
    Provide a brief explanation (3-4 sentences) of why irrigation is {status} and best practices for watering.
    """
    return get_gemini_response(prompt)