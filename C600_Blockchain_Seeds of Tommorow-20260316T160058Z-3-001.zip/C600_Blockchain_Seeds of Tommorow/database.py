import sqlite3
from datetime import datetime
import hashlib
from config import Config

def get_db_connection():
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            user_type TEXT NOT NULL,
            location TEXT,
            phone TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            farmer_id INTEGER NOT NULL,
            crop_name TEXT NOT NULL,
            quantity REAL NOT NULL,
            price REAL NOT NULL,
            harvest_date TEXT,
            cultivation_method TEXT,
            description TEXT,
            blockchain_hash TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (farmer_id) REFERENCES users (id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            farmer_id INTEGER NOT NULL,
            quantity REAL NOT NULL,
            total_amount REAL NOT NULL,
            transaction_id TEXT UNIQUE NOT NULL,
            payment_method TEXT,
            blockchain_hash TEXT,
            status TEXT DEFAULT 'completed',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES users (id),
            FOREIGN KEY (product_id) REFERENCES products (id),
            FOREIGN KEY (farmer_id) REFERENCES users (id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS cart (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES users (id),
            FOREIGN KEY (product_id) REFERENCES products (id)
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            prediction_type TEXT NOT NULL,
            input_data TEXT NOT NULL,
            output_result TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    conn.commit()
    conn.close()

def create_user(name, email, password, user_type, location=None, phone=None):
    conn = get_db_connection()
    cursor = conn.cursor()
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    cursor.execute('INSERT INTO users (name, email, password, user_type, location, phone) VALUES (?, ?, ?, ?, ?, ?)',
                   (name, email, hashed_password, user_type, location, phone))
    conn.commit()
    user_id = cursor.lastrowid
    conn.close()
    return user_id

def get_user_by_email(email):
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
    conn.close()
    return user

def verify_user(email, password):
    user = get_user_by_email(email)
    if user:
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        if user['password'] == hashed_password:
            return user
    return None

def get_user_by_id(user_id):
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    conn.close()
    return user

def add_product(farmer_id, crop_name, quantity, price, harvest_date, cultivation_method, description, blockchain_hash):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO products (farmer_id, crop_name, quantity, price, harvest_date, cultivation_method, description, blockchain_hash)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                   (farmer_id, crop_name, quantity, price, harvest_date, cultivation_method, description, blockchain_hash))
    conn.commit()
    product_id = cursor.lastrowid
    conn.close()
    return product_id

def get_all_products():
    conn = get_db_connection()
    products = conn.execute('SELECT * FROM products WHERE quantity > 0 ORDER BY created_at DESC').fetchall()
    conn.close()
    return products

def get_product_by_id(product_id):
    conn = get_db_connection()
    product = conn.execute('SELECT * FROM products WHERE id = ?', (product_id,)).fetchone()
    conn.close()
    return product

def get_products_by_farmer(farmer_id):
    conn = get_db_connection()
    products = conn.execute('SELECT * FROM products WHERE farmer_id = ? ORDER BY created_at DESC', (farmer_id,)).fetchall()
    conn.close()
    return products

def add_to_cart(customer_id, product_id, quantity):
    conn = get_db_connection()
    cursor = conn.cursor()
    existing = conn.execute('SELECT * FROM cart WHERE customer_id = ? AND product_id = ?', (customer_id, product_id)).fetchone()
    if existing:
        cursor.execute('UPDATE cart SET quantity = quantity + ? WHERE customer_id = ? AND product_id = ?',
                       (quantity, customer_id, product_id))
    else:
        cursor.execute('INSERT INTO cart (customer_id, product_id, quantity) VALUES (?, ?, ?)',
                       (customer_id, product_id, quantity))
    conn.commit()
    conn.close()

def get_cart_items(customer_id):
    conn = get_db_connection()
    items = conn.execute('''
        SELECT 
            cart.id as cart_id,
            cart.quantity,
            cart.product_id,
            products.id as product_id,
            products.farmer_id,
            products.crop_name,
            products.price,
            products.harvest_date,
            products.cultivation_method,
            products.description,
            products.blockchain_hash,
            products.quantity as available_quantity
        FROM cart
        JOIN products ON cart.product_id = products.id
        WHERE cart.customer_id = ?
    ''', (customer_id,)).fetchall()
    conn.close()
    return items

def remove_from_cart(cart_id):
    conn = get_db_connection()
    conn.execute('DELETE FROM cart WHERE id = ?', (cart_id,))
    conn.commit()
    conn.close()

def clear_cart(customer_id):
    conn = get_db_connection()
    conn.execute('DELETE FROM cart WHERE customer_id = ?', (customer_id,))
    conn.commit()
    conn.close()

def create_transaction(customer_id, product_id, farmer_id, quantity, total_amount, transaction_id, payment_method, blockchain_hash):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO transactions (customer_id, product_id, farmer_id, quantity, total_amount, transaction_id, payment_method, blockchain_hash)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                   (customer_id, product_id, farmer_id, quantity, total_amount, transaction_id, payment_method, blockchain_hash))
    conn.commit()
    conn.close()

def update_product_quantity(product_id, quantity_sold):
    conn = get_db_connection()
    conn.execute('UPDATE products SET quantity = quantity - ? WHERE id = ?', (quantity_sold, product_id))
    conn.commit()
    conn.close()

def get_transactions_by_customer(customer_id):
    conn = get_db_connection()
    transactions = conn.execute('''
        SELECT transactions.*, products.crop_name, products.price, users.name as farmer_name
        FROM transactions
        JOIN products ON transactions.product_id = products.id
        JOIN users ON transactions.farmer_id = users.id
        WHERE transactions.customer_id = ?
        ORDER BY transactions.created_at DESC
    ''', (customer_id,)).fetchall()
    conn.close()
    return transactions

def get_sales_by_farmer(farmer_id):
    conn = get_db_connection()
    sales = conn.execute('''
        SELECT transactions.*, products.crop_name, users.name as customer_name
        FROM transactions
        JOIN products ON transactions.product_id = products.id
        JOIN users ON transactions.customer_id = users.id
        WHERE transactions.farmer_id = ?
        ORDER BY transactions.created_at DESC
    ''', (farmer_id,)).fetchall()
    conn.close()
    return sales

def save_prediction(user_id, prediction_type, input_data, output_result):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO predictions (user_id, prediction_type, input_data, output_result) VALUES (?, ?, ?, ?)',
                   (user_id, prediction_type, str(input_data), str(output_result)))
    conn.commit()
    conn.close()

def get_predictions_by_user(user_id):
    conn = get_db_connection()
    predictions = conn.execute('SELECT * FROM predictions WHERE user_id = ? ORDER BY created_at DESC', (user_id,)).fetchall()
    conn.close()
    return predictions