from web3 import Web3
from solcx import compile_source, install_solc
import json
import os
from config import Config

install_solc('0.8.0')

w3 = Web3(Web3.HTTPProvider(Config.GANACHE_URL))

CONTRACT_FILE = 'contracts/FarmingPlatform.sol'
DEPLOYED_FILE = 'contracts/deployed.json'

def compile_contract():
    with open(CONTRACT_FILE, 'r') as f:
        source = f.read()
    compiled = compile_source(source, output_values=['abi', 'bin'], solc_version='0.8.0')
    contract_id, contract_interface = list(compiled.items())[0]
    return contract_interface['abi'], contract_interface['bin']

def deploy_contract():
    if os.path.exists(DEPLOYED_FILE):
        with open(DEPLOYED_FILE, 'r') as f:
            data = json.load(f)
        print(f"Contract already deployed at: {data['address']}")
        return data['address'], data['abi']

    print("Deploying contract to Ganache...")
    abi, bytecode = compile_contract()

    contract = w3.eth.contract(abi=abi, bytecode=bytecode)
    account = w3.eth.accounts[0]

    tx_hash = contract.constructor().transact({'from': account, 'gas': 5000000})
    tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

    address = tx_receipt.contractAddress
    print(f"Contract deployed at: {address}")

    with open(DEPLOYED_FILE, 'w') as f:
        json.dump({'address': address, 'abi': abi}, f)

    return address, abi

def get_contract():
    if not os.path.exists(DEPLOYED_FILE):
        deploy_contract()
    with open(DEPLOYED_FILE, 'r') as f:
        data = json.load(f)
    return w3.eth.contract(address=data['address'], abi=data['abi'])

def store_product_on_blockchain(product_id, farmer_name, crop_name, quantity, price, harvest_date, cultivation_method):
    try:
        contract = get_contract()
        account = w3.eth.accounts[0]

        tx_hash = contract.functions.addProduct(
            int(product_id),
            str(farmer_name),
            str(crop_name),
            int(quantity),
            int(price),
            str(harvest_date),
            str(cultivation_method)
        ).transact({'from': account, 'gas': 1000000})

        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        blockchain_hash = receipt.transactionHash.hex()
        print(f"Product stored on blockchain: {blockchain_hash}")
        return blockchain_hash

    except Exception as e:
        print(f"Blockchain product error: {e}")
        return None

def store_transaction_on_blockchain(product_id, crop_name, quantity, total_amount, transaction_id, payment_method, farmer_address=None):
    try:
        contract = get_contract()
        accounts = w3.eth.accounts
        buyer_account = accounts[1] if len(accounts) > 1 else accounts[0]
        farmer_account = farmer_address if farmer_address else accounts[0]

        tx_hash = contract.functions.addTransaction(
            int(product_id),
            str(crop_name),
            int(quantity),
            int(total_amount),
            str(transaction_id),
            str(payment_method),
            farmer_account
        ).transact({'from': buyer_account, 'gas': 1000000})

        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        blockchain_hash = receipt.transactionHash.hex()
        print(f"Transaction stored on blockchain: {blockchain_hash}")
        return blockchain_hash

    except Exception as e:
        print(f"Blockchain transaction error: {e}")
        return None

def get_product_from_blockchain(product_id):
    try:
        contract = get_contract()
        result = contract.functions.getProduct(int(product_id)).call()
        return {
            'farmer_address': result[0],
            'farmer_name': result[1],
            'crop_name': result[2],
            'quantity': result[3],
            'price': result[4],
            'harvest_date': result[5],
            'cultivation_method': result[6],
            'timestamp': result[7]
        }
    except Exception as e:
        print(f"Error reading product from blockchain: {e}")
        return None

def get_transaction_from_blockchain(index):
    try:
        contract = get_contract()
        result = contract.functions.getTransaction(int(index)).call()
        return {
            'buyer_address': result[0],
            'farmer_address': result[1],
            'crop_name': result[2],
            'quantity': result[3],
            'total_amount': result[4],
            'transaction_id': result[5],
            'payment_method': result[6],
            'timestamp': result[7]
        }
    except Exception as e:
        print(f"Error reading transaction from blockchain: {e}")
        return None

def is_connected():
    try:
        return w3.is_connected()
    except Exception:
        return False