import pickle
import numpy as np
import pandas as pd
from config import Config

class ModelLoader:
    def __init__(self):
        self.crop_model = None
        self.fertilizer_model = None
        self.irrigation_model = None
        self.soil_encoder = None
        self.crop_encoder = None
        self.load_models()
    
    def load_models(self):
        try:
            with open('models/crop_recommendation_model.pkl', 'rb') as f:
                self.crop_model = pickle.load(f)
            
            with open('models/fertilizer_recommendation_model.pkl', 'rb') as f:
                self.fertilizer_model = pickle.load(f)
            
            with open('models/irrigation_model.pkl', 'rb') as f:
                self.irrigation_model = pickle.load(f)
            
            with open('models/soil_encoder.pkl', 'rb') as f:
                self.soil_encoder = pickle.load(f)
            
            with open('models/crop_encoder.pkl', 'rb') as f:
                self.crop_encoder = pickle.load(f)
            
            print("All models loaded successfully")
        except Exception as e:
            print(f"Error loading models: {e}")
    
    def predict_crop(self, N, P, K, temperature, humidity, ph, rainfall):
        input_data = np.array([[N, P, K, temperature, humidity, ph, rainfall]])
        prediction = self.crop_model.predict(input_data)
        return prediction[0]
    
    def predict_fertilizer(self, temperature, humidity, moisture, soil_type, crop_type, nitrogen, potassium, phosphorous):
        soil_encoded = self.soil_encoder.transform([soil_type])[0]
        crop_encoded = self.crop_encoder.transform([crop_type])[0]
        input_data = np.array([[temperature, humidity, moisture, soil_encoded, crop_encoded, nitrogen, potassium, phosphorous]])
        prediction = self.fertilizer_model.predict(input_data)
        return prediction[0]
    
    def predict_irrigation(self, soil_moisture, temperature, soil_humidity, air_temperature, wind_speed, air_humidity, wind_gust, pressure):
        input_data = np.array([[soil_moisture, temperature, soil_humidity, air_temperature, wind_speed, air_humidity, wind_gust, pressure]])
        prediction = self.irrigation_model.predict(input_data)
        return prediction[0]

model_loader = ModelLoader()