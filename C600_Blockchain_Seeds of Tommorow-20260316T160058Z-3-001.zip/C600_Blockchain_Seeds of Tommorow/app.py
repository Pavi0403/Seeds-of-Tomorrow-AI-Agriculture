from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import os
from datetime import datetime
import hashlib
import uuid
from config import Config
import database
from model_loader import model_loader
import gemini_helper
import json
import blockchain

app = Flask(__name__)
app.config.from_object(Config)

database.init_db()
blockchain.deploy_contract()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        user_type = request.form.get('user_type')
        location = request.form.get('location')
        phone = request.form.get('phone')

        existing_user = database.get_user_by_email(email)
        if existing_user:
            flash('Email already exists', 'error')
            return redirect(url_for('signup'))

        user_id = database.create_user(name, email, password, user_type, location, phone)
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = database.verify_user(email, password)
        if user:
            session['user_id'] = user['id']
            session['user_name'] = user['name']
            session['user_type'] = user['user_type']

            if user['user_type'] == 'farmer':
                return redirect(url_for('farmer_dashboard'))
            else:
                return redirect(url_for('user_dashboard'))
        else:
            flash('Invalid email or password', 'error')
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('index'))

@app.route('/farmer_dashboard')
def farmer_dashboard():
    if 'user_id' not in session or session.get('user_type') != 'farmer':
        flash('Please login as farmer', 'error')
        return redirect(url_for('login'))

    user = database.get_user_by_id(session['user_id'])
    products = database.get_products_by_farmer(session['user_id'])
    sales = database.get_sales_by_farmer(session['user_id'])
    predictions = database.get_predictions_by_user(session['user_id'])

    return render_template('farmer_dashboard.html', user=user, products=products, sales=sales, predictions=predictions)

@app.route('/user_dashboard')
def user_dashboard():
    if 'user_id' not in session or session.get('user_type') != 'customer':
        flash('Please login as customer', 'error')
        return redirect(url_for('login'))

    user = database.get_user_by_id(session['user_id'])
    products = database.get_all_products()
    cart_items = database.get_cart_items(session['user_id'])
    orders = database.get_transactions_by_customer(session['user_id'])

    return render_template('user_dashboard.html', user=user, products=products, cart_items=cart_items, orders=orders)

@app.route('/predict_crop', methods=['POST'])
def predict_crop():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login'})

    try:
        N = float(request.form.get('N'))
        P = float(request.form.get('P'))
        K = float(request.form.get('K'))
        temperature = float(request.form.get('temperature'))
        humidity = float(request.form.get('humidity'))
        ph = float(request.form.get('ph'))
        rainfall = float(request.form.get('rainfall'))

        prediction = model_loader.predict_crop(N, P, K, temperature, humidity, ph, rainfall)

        input_params = {
            'N': N, 'P': P, 'K': K, 'temperature': temperature,
            'humidity': humidity, 'ph': ph, 'rainfall': rainfall
        }

        explanation = gemini_helper.explain_crop_recommendation(prediction, input_params)

        database.save_prediction(session['user_id'], 'crop', json.dumps(input_params), prediction)

        session['prediction_result'] = {
            'type': 'crop',
            'result': prediction,
            'explanation': explanation,
            'input_params': input_params
        }

        return jsonify({'success': True, 'redirect': url_for('farmer_result')})

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/predict_fertilizer', methods=['POST'])
def predict_fertilizer():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login'})

    try:
        temperature = float(request.form.get('temperature'))
        humidity = float(request.form.get('humidity'))
        moisture = float(request.form.get('moisture'))
        soil_type = request.form.get('soil_type')
        crop_type = request.form.get('crop_type')
        nitrogen = float(request.form.get('nitrogen'))
        potassium = float(request.form.get('potassium'))
        phosphorous = float(request.form.get('phosphorous'))

        prediction = model_loader.predict_fertilizer(temperature, humidity, moisture, soil_type, crop_type, nitrogen, potassium, phosphorous)

        input_params = {
            'temperature': temperature, 'humidity': humidity, 'moisture': moisture,
            'soil_type': soil_type, 'crop_type': crop_type, 'nitrogen': nitrogen,
            'potassium': potassium, 'phosphorous': phosphorous
        }

        explanation = gemini_helper.explain_fertilizer_recommendation(prediction, input_params)

        database.save_prediction(session['user_id'], 'fertilizer', json.dumps(input_params), prediction)

        session['prediction_result'] = {
            'type': 'fertilizer',
            'result': prediction,
            'explanation': explanation,
            'input_params': input_params
        }

        return jsonify({'success': True, 'redirect': url_for('farmer_result')})

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/predict_irrigation', methods=['POST'])
def predict_irrigation():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login'})

    try:
        soil_moisture = float(request.form.get('soil_moisture'))
        temperature = float(request.form.get('temperature'))
        soil_humidity = float(request.form.get('soil_humidity'))
        air_temperature = float(request.form.get('air_temperature'))
        wind_speed = float(request.form.get('wind_speed'))
        air_humidity = float(request.form.get('air_humidity'))
        wind_gust = float(request.form.get('wind_gust'))
        pressure = float(request.form.get('pressure'))

        prediction = model_loader.predict_irrigation(soil_moisture, temperature, soil_humidity, air_temperature, wind_speed, air_humidity, wind_gust, pressure)

        input_params = {
            'soil_moisture': soil_moisture, 'temperature': temperature, 'soil_humidity': soil_humidity,
            'air_temperature': air_temperature, 'wind_speed': wind_speed, 'air_humidity': air_humidity,
            'wind_gust': wind_gust, 'pressure': pressure
        }

        explanation = gemini_helper.explain_irrigation_recommendation(prediction, input_params)

        database.save_prediction(session['user_id'], 'irrigation', json.dumps(input_params), prediction)

        session['prediction_result'] = {
            'type': 'irrigation',
            'result': prediction,
            'explanation': explanation,
            'input_params': input_params
        }

        return jsonify({'success': True, 'redirect': url_for('farmer_result')})

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/farmer_result')
def farmer_result():
    if 'user_id' not in session or 'prediction_result' not in session:
        return redirect(url_for('farmer_dashboard'))

    result = session.get('prediction_result')
    return render_template('farmer_result.html', result=result)

@app.route('/add_product', methods=['POST'])
def add_product():
    if 'user_id' not in session or session.get('user_type') != 'farmer':
        return jsonify({'success': False, 'message': 'Unauthorized'})

    try:
        crop_name = request.form.get('crop_name')
        quantity = float(request.form.get('quantity'))
        price = float(request.form.get('price'))
        harvest_date = request.form.get('harvest_date')
        cultivation_method = request.form.get('cultivation_method')
        description = request.form.get('description')

        user = database.get_user_by_id(session['user_id'])

        product_id = database.add_product(
            session['user_id'], crop_name, quantity, price,
            harvest_date, cultivation_method, description, 'pending'
        )

        blockchain_hash = blockchain.store_product_on_blockchain(
            product_id,
            user['name'],
            crop_name,
            int(quantity),
            int(price),
            harvest_date,
            cultivation_method or 'Natural'
        )

        if not blockchain_hash:
            product_data = f"{crop_name}_{user['name']}_{harvest_date}_{datetime.now().isoformat()}"
            blockchain_hash = hashlib.sha256(product_data.encode()).hexdigest()

        import sqlite3
        conn = sqlite3.connect(Config.DATABASE_PATH)
        conn.execute('UPDATE products SET blockchain_hash = ? WHERE id = ?', (blockchain_hash, product_id))
        conn.commit()
        conn.close()

        flash('Product added successfully', 'success')
        return jsonify({'success': True, 'redirect': url_for('farmer_dashboard')})

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    if 'user_id' not in session or session.get('user_type') != 'customer':
        return jsonify({'success': False, 'message': 'Please login as customer'})

    try:
        product_id = int(request.form.get('product_id'))
        quantity = float(request.form.get('quantity'))

        database.add_to_cart(session['user_id'], product_id, quantity)

        flash('Added to cart', 'success')
        return jsonify({'success': True})

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/remove_from_cart/<int:cart_id>', methods=['POST'])
def remove_from_cart(cart_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    database.remove_from_cart(cart_id)
    flash('Item removed from cart', 'success')
    return redirect(url_for('user_dashboard'))

@app.route('/checkout', methods=['POST'])
def checkout():
    if 'user_id' not in session or session.get('user_type') != 'customer':
        return jsonify({'success': False, 'message': 'Please login'})

    try:
        cart_items = database.get_cart_items(session['user_id'])

        if not cart_items:
            return jsonify({'success': False, 'message': 'Cart is empty'})

        payment_method = request.form.get('payment_method', 'upi')

        for item in cart_items:
            transaction_id = str(uuid.uuid4())
            total_amount = item['price'] * item['quantity']
            product_id = item['product_id']

            blockchain_hash = blockchain.store_transaction_on_blockchain(
                product_id,
                item['crop_name'],
                int(item['quantity']),
                int(total_amount),
                transaction_id,
                payment_method
            )

            if not blockchain_hash:
                transaction_data = f"{session['user_id']}_{product_id}_{transaction_id}_{datetime.now().isoformat()}"
                blockchain_hash = hashlib.sha256(transaction_data.encode()).hexdigest()

            database.create_transaction(
                session['user_id'],
                product_id,
                item['farmer_id'],
                item['quantity'],
                total_amount,
                transaction_id,
                payment_method,
                blockchain_hash
            )

            database.update_product_quantity(product_id, item['quantity'])

        database.clear_cart(session['user_id'])

        session['last_transaction_id'] = transaction_id

        flash('Order placed successfully', 'success')
        return jsonify({'success': True, 'redirect': url_for('user_result')})

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/payment')
def payment():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cart_items = database.get_cart_items(session['user_id'])
    total = sum(item['price'] * item['quantity'] for item in cart_items)

    return render_template('payment.html', cart_items=cart_items, total=total)

@app.route('/user_result')
def user_result():
    if 'user_id' not in session or 'last_transaction_id' not in session:
        return redirect(url_for('user_dashboard'))

    orders = database.get_transactions_by_customer(session['user_id'])

    return render_template('user_result.html', orders=orders)

if __name__ == '__main__':
    if not os.path.exists(Config.UPLOAD_FOLDER):
        os.makedirs(Config.UPLOAD_FOLDER)
    app.run(debug=True, port=5000)